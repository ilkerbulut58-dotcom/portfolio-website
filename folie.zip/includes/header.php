<!DOCTYPE html>
<html lang="de" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? 'Portfolio - Softwareentwickler' ?></title>
    <link rel="stylesheet" href="/assets/styles.css">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-background text-foreground min-h-screen">
    <header class="border-b border-border sticky top-0 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-50">
        <div class="container mx-auto px-4 h-16 flex items-center justify-between">
            <a href="/" class="text-xl font-bold">Portfolio</a>
            <nav class="flex gap-6">
                <a href="/" class="hover:text-primary transition-colors">Start</a>
                <a href="/projects.php" class="hover:text-primary transition-colors">Projekte</a>
                <a href="/about.php" class="hover:text-primary transition-colors">Über Mich</a>
                <a href="/contact.php" class="hover:text-primary transition-colors">Kontakt</a>
                <a href="/admin/" class="hover:text-primary transition-colors">Admin</a>
            </nav>
        </div>
    </header>
    <main class="flex-1">
