<?php
require_once 'config/database.php';
$pageTitle = 'Projekte - Portfolio';

// Get filter category from query string
$category = $_GET['category'] ?? 'Alle';

// Fetch projects
$db = getDB();
if ($category === 'Alle') {
    $stmt = $db->prepare("SELECT * FROM projects ORDER BY created_at DESC");
    $stmt->execute();
} else {
    $stmt = $db->prepare("SELECT * FROM projects WHERE category = ? ORDER BY created_at DESC");
    $stmt->execute([$category]);
}
$projects = $stmt->fetchAll();

// Get unique categories
$categoriesStmt = $db->query("SELECT DISTINCT category FROM projects");
$categories = $categoriesStmt->fetchAll(PDO::FETCH_COLUMN);

require_once 'includes/header.php';
?>

<div class="container mx-auto px-4 py-12">
    <h1 class="text-4xl font-bold mb-2">Meine Projekte</h1>
    <p class="text-muted-foreground mb-8">Eine Auswahl meiner bisherigen Arbeiten und Entwicklungsprojekte</p>
    
    <!-- Category Filter -->
    <div class="flex gap-2 mb-8 flex-wrap">
        <a href="?category=Alle" class="px-4 py-2 rounded-md <?= $category === 'Alle' ? 'bg-primary text-primary-foreground' : 'bg-secondary' ?>">
            Alle
        </a>
        <?php foreach ($categories as $cat): ?>
            <a href="?category=<?= urlencode($cat) ?>" class="px-4 py-2 rounded-md <?= $category === $cat ? 'bg-primary text-primary-foreground' : 'bg-secondary' ?>">
                <?= htmlspecialchars($cat) ?>
            </a>
        <?php endforeach; ?>
    </div>
    
    <!-- Projects Grid -->
    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php foreach ($projects as $project): 
            $technologies = json_decode($project['technologies'], true);
        ?>
            <div class="border border-border rounded-lg overflow-hidden hover:border-primary transition-colors">
                <div class="p-6">
                    <h3 class="text-xl font-bold mb-2"><?= htmlspecialchars($project['title']) ?></h3>
                    <p class="text-muted-foreground mb-4"><?= htmlspecialchars($project['description']) ?></p>
                    
                    <div class="flex flex-wrap gap-2 mb-4">
                        <?php foreach ($technologies as $tech): ?>
                            <span class="px-2 py-1 bg-secondary text-xs rounded">
                                <?= htmlspecialchars($tech) ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                    
                    <a href="/project.php?id=<?= $project['id'] ?>" class="text-primary hover:underline">
                        Details ansehen →
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
