# Portfolio Website - PHP/MySQL Version

## 📋 Anforderungen

- PHP 7.4 oder höher
- MySQL 5.7 oder höher
- Apache oder Nginx Webserver

## 🚀 Installation auf Ionos Shared Hosting

### Schritt 1: Dateien hochladen

1. Laden Sie alle Dateien aus dem `php/` Ordner via FTP hoch
2. Platzieren Sie die Dateien im Hauptverzeichnis (public_html oder htdocs)

### Schritt 2: Datenbank erstellen

1. Melden Sie sich im Ionos Control Panel an
2. Gehen Sie zu "Datenbanken" → "MySQL"
3. Erstellen Sie eine neue Datenbank
4. Notieren Sie:
   - Datenbankname
   - Benutzername
   - Passwort
   - Hostname (meist: localhost)

### Schritt 3: Database Config anpassen

Bearbeiten Sie `config/database.php`:

```php
define('DB_HOST', 'localhost');  // oder Ihr Ionos DB Host
define('DB_NAME', 'ihr_db_name');
define('DB_USER', 'ihr_db_user');
define('DB_PASS', 'ihr_db_passwort');
```

### Schritt 4: Datenbank importieren

1. Öffnen Sie phpMyAdmin in Ionos
2. Wählen Sie Ihre Datenbank
3. Gehen Sie zu "Import"
4. Laden Sie die Datei `config/schema.sql` hoch
5. Klicken Sie "Ausführen"

✅ Fertig! Ihre Website ist jetzt live unter `ihre-domain.de`

## 📁 Dateistruktur

```
php/
├── index.php              # Startseite
├── projects.php           # Projektliste
├── project.php            # Projektdetails
├── about.php              # Über Mich
├── contact.php            # Kontaktformular
├── admin/                 # Admin Panel
│   ├── index.php          # Login
│   ├── projects.php       # Projektverwaltung
│   ├── project_form.php   # Projekt erstellen/bearbeiten
│   └── logout.php         # Logout
├── config/
│   ├── database.php       # DB Verbindung
│   └── schema.sql         # DB Schema & Sample Data
├── includes/
│   ├── header.php         # Header Template
│   └── footer.php         # Footer Template
└── assets/
    └── styles.css         # Custom CSS
```

## 🔒 Admin Panel

**URL:** `ihre-domain.de/admin/`

**Login:**
- Passwort: `admin123` (bitte ändern!)

**Funktionen:**
- ✅ Projekte erstellen
- ✅ Projekte bearbeiten
- ✅ Projekte löschen
- ✅ Kommagetrennte Eingabe für Technologien/Features

**Passwort ändern:**
Bearbeiten Sie `admin/index.php` Zeile 6:
```php
$admin_password = 'IhrNeuesPasswort';
```

## 🎨 Design

- **Dark Mode** als Standard
- **Tailwind CSS** via CDN
- **Responsive** für Mobile, Tablet, Desktop
- **Professionell** für deutsche Bewerbungen

## 📝 Seiten

1. **Startseite** (`/`) - Hero + Skills Übersicht
2. **Projekte** (`/projects.php`) - Galerie mit Kategorie-Filter
3. **Projektdetails** (`/project.php?id=...`) - Einzelansicht
4. **Über Mich** (`/about.php`) - Persönliche Vorstellung
5. **Kontakt** (`/contact.php`) - Kontaktformular
6. **Admin** (`/admin/`) - Projektverwaltung

## 🔧 Ionos-spezifische Hinweise

### .htaccess für Clean URLs (optional)

Erstellen Sie `.htaccess` im Hauptverzeichnis:

```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^projekte/([a-zA-Z0-9-]+)$ /project.php?id=$1 [L]
```

### PHP Version einstellen

In Ionos Control Panel:
1. Hosting → Einstellungen
2. PHP Version: mindestens 7.4

### SSL/HTTPS aktivieren

1. Ionos Control Panel → SSL
2. Kostenloses SSL-Zertifikat aktivieren
3. HTTPS erzwingen

## ✅ Features

- ✅ 6 Beispielprojekte vorinstalliert
- ✅ MySQL Datenbank mit JSON-Support
- ✅ Admin Panel mit Session-basierter Auth
- ✅ Kontaktformular mit DB-Speicherung
- ✅ Responsive Design
- ✅ Dark Mode
- ✅ Kategorie-Filter
- ✅ Sauberer, wartbarer Code

## 🆘 Support

Bei Problemen:
1. Prüfen Sie DB-Verbindung in `config/database.php`
2. Checken Sie PHP Error Log in Ionos
3. Stellen Sie sicher, dass `schema.sql` importiert wurde

## 📌 Unterschied zu Node.js Version

| Feature | PHP/MySQL | Node.js/React |
|---------|-----------|---------------|
| Hosting | Shared Hosting (3-5€/Monat) | VPS nötig (10-15€/Monat) |
| Setup | Einfach (FTP Upload) | Komplex (SSH, PM2, Nginx) |
| Admin Panel | ✅ Funktional | ✅ Fortgeschritten |
| Performance | Gut | Sehr gut |
| Modern UI | Tailwind CSS | React + Shadcn |

**Empfehlung:** PHP/MySQL für Ionos Shared Hosting perfekt geeignet!
