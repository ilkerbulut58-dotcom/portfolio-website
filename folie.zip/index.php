<?php
$pageTitle = 'Start - Portfolio';
require_once 'includes/header.php';
?>

<section class="py-20 px-4">
    <div class="container mx-auto text-center">
        <h1 class="text-5xl font-bold mb-4">Softwareentwickler & Projektmanager</h1>
        <p class="text-xl text-muted-foreground mb-8">Spezialisiert auf Full-Stack-Entwicklung und moderne Webanwendungen</p>
        <a href="/projects.php" class="inline-block bg-primary text-primary-foreground px-6 py-3 rounded-md hover:bg-primary/90 transition-colors">
            Projekte ansehen
        </a>
    </div>
</section>

<section class="py-12 px-4">
    <div class="container mx-auto">
        <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div class="p-6 border border-border rounded-lg">
                <h3 class="text-xl font-bold mb-2">Frontend-Entwicklung</h3>
                <p class="text-muted-foreground">Moderne, responsive Benutzeroberflächen mit React, TypeScript und modernen CSS-Frameworks</p>
            </div>
            <div class="p-6 border border-border rounded-lg">
                <h3 class="text-xl font-bold mb-2">Backend-Entwicklung</h3>
                <p class="text-muted-foreground">Robuste Server-Anwendungen mit Node.js, PHP und Python</p>
            </div>
            <div class="p-6 border border-border rounded-lg">
                <h3 class="text-xl font-bold mb-2">Datenbanken</h3>
                <p class="text-muted-foreground">Design und Optimierung relationaler und NoSQL-Datenbanken</p>
            </div>
            <div class="p-6 border border-border rounded-lg">
                <h3 class="text-xl font-bold mb-2">Full-Stack-Projekte</h3>
                <p class="text-muted-foreground">End-to-End-Entwicklung kompletter Anwendungen von der Idee bis zum Deployment</p>
            </div>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
